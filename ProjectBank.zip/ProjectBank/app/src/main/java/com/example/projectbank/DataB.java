package com.example.projectbank;

public class DataB {
    String fname;
    String add;
    String gen;
    String Age;
    String DateofBirth;
    String cell;

    public String getFname() {
        return fname;
    }

    public String getAdd() {
        return add;
    }

    public String getGen() {
        return gen;
    }

    public String getAge() {
        return Age;
    }

    public String getDateofBirth() {
        return DateofBirth;
    }

    public String getCell() {
        return cell;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public void setAdd(String add) {
        this.add = add;
    }

    public void setGen(String gen) {
        this.gen = gen;
    }

    public void setAge(String age) {
        Age = age;
    }

    public void setDateofBirth(String dateofBirth) {
        DateofBirth = dateofBirth;
    }

    public void setCell(String cell) {
        this.cell = cell;
    }

    public DataB(String fname, String add, String gen, String age, String dateofBirth, String cell) {
        this.fname = fname;
        this.add = add;
        this.gen = gen;
        Age = age;
        DateofBirth = dateofBirth;
        this.cell = cell;

    }
}

