package com.example.projectbank;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ReceiveMoney extends AppCompatActivity {
    private Button Send,Back;
    private EditText Amount;

    DatabaseReference Banking;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_money);

        Send = findViewById(R.id.btn_SendRM);
        Back = findViewById(R.id.btn_BackRM);

        Amount = findViewById(R.id.etEnterAmount);

        Banking = FirebaseDatabase.getInstance().getReference().child("Money").child("Cash");


        Send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertMoney();

            }
        });


        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),Dashboard.class);
                startActivity(intent);
            }
        });

    }

    private void insertMoney() {
        Double CashIn = Double.parseDouble(Amount.getText().toString());
        Intent intent = new Intent(getApplicationContext(), Dashboard.class);
        intent.putExtra("Amount", CashIn);
        ForCash forCash = new ForCash(CashIn);
        Banking.push().setValue(forCash);
        startActivity(intent);

    }
}