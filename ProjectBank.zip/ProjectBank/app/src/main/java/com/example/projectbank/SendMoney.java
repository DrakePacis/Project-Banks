package com.example.projectbank;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SendMoney extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_money);
    }
}