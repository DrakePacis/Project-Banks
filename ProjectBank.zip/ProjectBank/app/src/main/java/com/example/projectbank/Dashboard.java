package com.example.projectbank;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SurfaceControl;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Dashboard extends AppCompatActivity {
    Button CashInDash, Sendmoney, Paybills;
    TextView Balance;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        CashInDash = findViewById(R.id.btn_AddMoney);
        Sendmoney = findViewById(R.id.btn_SendMoney);
        Paybills = findViewById(R.id.btn_PayBills);

        Balance = findViewById(R.id.tv_Balance);
        getIntent().getDoubleExtra("Amount", 0);
        double CashIn = getIntent().getDoubleExtra("Amount", 0);
        Balance.setText("BALANCE: " + CashIn);

        Paybills.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), PayBills.class);
                startActivity(intent);
            }
        });

        Sendmoney.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), SendMoney.class);
                startActivity(intent);
            }
        });



        CashInDash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Dashboard.this, ReceiveMoney.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.app_bar_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.UserMenu:
                Intent intent1 = new Intent(getApplicationContext(), Userss.class);
                startActivity(intent1);
                return true;
            case R.id.TransactionMenu:
                Intent intent2 = new Intent(getApplicationContext(), Transaction.class);
                startActivity(intent2);
                return true;
            case R.id.LogoutMenu:
                Intent intent3 = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent3);
                return true;

        }
        return super.onOptionsItemSelected(item);
    }
}