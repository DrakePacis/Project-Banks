package com.example.projectbank;

public class ForCash {
   Double CashIn;

    public ForCash(Double cashIn) {
        CashIn = cashIn;
    }

    public Double getCashIn() {
        return CashIn;
    }

    public void setCashIn(Double cashIn) {
        CashIn = cashIn;
    }
}
